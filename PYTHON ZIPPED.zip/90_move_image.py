from tkinter import *

window = Tk()
window.geometry("500x500")

image_path = r"C:\Users\navgh\Downloads\Python Prog\rice.jpeg"
myimage = PhotoImage(file=image_path)
label = Label(window,image=myimage,bg="red")
label.image = myimage  # Keep a reference to the image

label.place(x=0,y=0)
window.mainloop()