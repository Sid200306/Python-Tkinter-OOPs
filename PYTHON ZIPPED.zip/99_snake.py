from tkinter import *
import random

# Constants
GAME_WIDTH = 500
GAME_HEIGHT = 500
SPEED = 100
SPACE_SIZE = 20
BODY_PARTS = 3
SNAKE_COLOUR = "green"
FOOD_COLOUR = "red"
BACKGROUND_COLOUR = "black"

class Snake:
    def __init__(self):
        self.body_size = BODY_PARTS
        self.coordinates = []
        self.squares = []

        for i in range(0, BODY_PARTS):
            self.coordinates.append([0, 0])

        for x, y in self.coordinates:
            square = canvas.create_rectangle(x, y, x + SPACE_SIZE, y + SPACE_SIZE, fill=SNAKE_COLOUR, tag="snake")
            self.squares.append(square)

class Food:
    def __init__(self):
        x = random.randint(0, (GAME_WIDTH / SPACE_SIZE) - 1) * SPACE_SIZE
        y = random.randint(0, (GAME_HEIGHT / SPACE_SIZE) - 1) * SPACE_SIZE
        self.coordinates = [x, y]
        canvas.create_oval(x, y, x + SPACE_SIZE, y + SPACE_SIZE, fill=FOOD_COLOUR, tag="food")

def next_turn(snake, food):
    x, y = snake.coordinates[0]

    if direction == "up":
        y -= SPACE_SIZE
    elif direction == "down":
        y += SPACE_SIZE
    elif direction == "left":
        x -= SPACE_SIZE
    elif direction == "right":
        x += SPACE_SIZE

    snake.coordinates.insert(0, [x, y])
    square = canvas.create_rectangle(x, y, x + SPACE_SIZE, y + SPACE_SIZE, fill=SNAKE_COLOUR)
    snake.squares.insert(0, square)

    if x == food.coordinates[0] and y == food.coordinates[1]:
        eat_food(snake, food)
    else:
        del snake.coordinates[-1]
        canvas.delete(snake.squares[-1])
        del snake.squares[-1]

    check_collisions(snake)

    window.after(SPEED, next_turn, snake, food)

def eat_food(snake, food):
    global score
    score += 1
    label.config(text="Score: {}".format(score))

    x = random.randint(0, (GAME_WIDTH / SPACE_SIZE) - 1) * SPACE_SIZE
    y = random.randint(0, (GAME_HEIGHT / SPACE_SIZE) - 1) * SPACE_SIZE

    food.coordinates = [x, y]
    canvas.coords("food", x, y, x + SPACE_SIZE, y + SPACE_SIZE)

def change_direction(new_direction):
    global direction
    if new_direction == "up" and not direction == "down":
        direction = "up"
    elif new_direction == "down" and not direction == "up":
        direction = "down"
    elif new_direction == "left" and not direction == "right":
        direction = "left"
    elif new_direction == "right" and not direction == "left":
        direction = "right"

def check_collisions(snake):
    x, y = snake.coordinates[0]

    if x < 0 or x >= GAME_WIDTH or y < 0 or y >= GAME_HEIGHT:
        game_over()

    for segment in snake.coordinates[1:]:
        if x == segment[0] and y == segment[1]:
            game_over()

def game_over():
    canvas.create_text(GAME_WIDTH / 2, GAME_HEIGHT / 2, text="Game Over", fill="white", font=("Helvetica", 16), anchor="center")
    window.quit()

# Main program
window = Tk()
window.title("Snake Game")

score = 0
direction = 'down'

label = Label(window, text="Score: {}".format(score), font=("consolas", 16), fg="white", bg="black")
label.pack()

canvas = Canvas(window, bg=BACKGROUND_COLOUR, height=GAME_HEIGHT, width=GAME_WIDTH)
canvas.pack()

window_width = window.winfo_width()
window_height = window.winfo_height()
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

x = int((screen_width / 2) - (window_width / 2))
y = int((screen_height / 2) - (window_height / 2))

window.geometry(f"{GAME_WIDTH}x{GAME_HEIGHT}+{x}+{y}")

snake = Snake()
food = Food()

window.bind("<Up>", lambda event: change_direction("up"))
window.bind("<Down>", lambda event: change_direction("down"))
window.bind("<Left>", lambda event: change_direction("left"))
window.bind("<Right>", lambda event: change_direction("right"))

window.after(SPEED, next_turn, snake, food)
window.mainloop()
