# prevents an user of creating an object of that class
# and compels a user to override abstract methofds in a child class

# abstract class = a class which contains one or more abstract methods
# abstract methods = a method that has a declaration but not any implemetation

from abc import ABC, abstractmethod

class Vehicle(ABC):

    @abstractmethod
    def go(self):
        pass

    @abstractmethod
    def stop(self):
        pass

class Car(Vehicle):

        def go(self):
            print("You drive the car")

        def stop(self):
            print("This car is stopped")
    
class Motorcycle(Vehicle):

        def go(self):
            print("You ride the car")
        
        def stop(self):
            print("This motorcycle is stopped")
#vehicle = Vehicle()
car = Car()
motorcycle = Motorcycle()

#vehicle.go()
car.go()
motorcycle.go()


car.stop()
motorcycle.stop()

