# buttons = when you click it, then it does stuff

from tkinter import *

count = 0

def click():
    global count
    count+=1
    print(count)

window = Tk()

button = Button(window,
                text='Click Me!!!!',
                command=click,
                font=("Comic Sans",30,),
                fg="#fa020f",
                bg="black",
                activeforeground="#fa020f",
                activebackground="black",
                state=ACTIVE,)
button.pack()



window.mainloop()
