import os

source = "abc.txt"
destination = "C:\\Users\\navgh\\Desktop\\abc.txt"

try:
    if os.path.exists(destination):
        print("There is already a file there")  