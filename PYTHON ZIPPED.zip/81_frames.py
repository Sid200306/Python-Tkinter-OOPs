# frames = a rectangular container to group or hold widgets

from tkinter import *

window = Tk()

frame = Frame(window,bg="pink",bd=5,relief=RAISED)
frame.pack()

Button(frame,text="S",font=("Consolas",25),width=3).pack(side=LEFT)
Button(frame,text="I",font=("Consolas",25),width=3).pack(side=LEFT)
Button(frame,text="D",font=("Consolas",25),width=3).pack(side=LEFT)
Button(frame,text="D",font=("Consolas",25),width=3).pack(side=LEFT)




window.mainloop()