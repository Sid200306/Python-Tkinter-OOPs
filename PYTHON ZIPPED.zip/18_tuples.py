# tuple = a collection whic is ordered and unchangeable
#         used to group together related data

student = ("Sidd","20","male")

#print(student.count("Sidd"))
#print(student.index("male")) 

for x in student:
    print(x)

if "Sidd" in student:
    print("Sidd is here!!")      