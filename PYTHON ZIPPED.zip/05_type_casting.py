#type casting = convert the data type of value into another data type
'''' 
x = 1 #int
y = 2.0 #float
z = "3" #str


print("X is "+str(x))
print("Y is "+str(y))
print(z)
''''' 