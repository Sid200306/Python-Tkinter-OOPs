# walrus opeartor :=

# new to Python 38
# asssignment expression aka walrus operator
# assigns values to variables as a part of larger expressions

#happy = True
#print(happy)

#print(happy := True)

#food = list()
#while True :
 #   food = input("What food do you like?: ")
 #   if food == "quit":
 #    break
 #    foods.append(food)


foods = list()
while food := input("What food do you like?: ") != "quit":
    foods.append(food)
