# zip(*iterables) = agggregate elements from two or more iterables (list,tuples,sets etc)
#                   creates a zip object with paired elements stored in tuples for each element.

usernames = ["Dude","Bro","Mister"]
password = ("p@ssword","guest","abc1233")
login_time = ["2am","6am","5pm"]

users = zip(usernames,password,login_time)


print(type(users))

for i in users:
    print(i)