# while loop = a statement thatw ill exceute its block of code as long as its condition remains true

#while 1==1:
    #print("Help! I'm stuck in a loop!!")

name = ""

while len(name) == 0:
    name = input("Enter your name:")

print("Hello "+name)