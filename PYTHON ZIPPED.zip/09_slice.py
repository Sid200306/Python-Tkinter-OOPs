website1 = "https://google.com"
website2 = "https://youtube.com"

slice = slice(8,-4)
print(website2[slice]) 