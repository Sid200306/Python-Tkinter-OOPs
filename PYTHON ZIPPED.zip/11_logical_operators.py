#logical operators = (and,or,not) used to check if two or more conditional statements are true
'''
temp = int(input("How is the temperature today?!"))

if temp >= 0 and temp <= 30:
    print("The temperature is good today, go outside!!")
elif temp < 0 or temp > 30:
    print("The temperature is bad today, stay inside!!") 
    '''

# not logical operator = makes true into false and false into true
temp = int(input("How is the temperature today?!"))

if not(temp >= 0 and temp <= 30):
    print("The temperature is good today, go outside!!")
elif not(temp < 0 or temp > 30):
    print("The temperature is bad today, stay inside!!") 
