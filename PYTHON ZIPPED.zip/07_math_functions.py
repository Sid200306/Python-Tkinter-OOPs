import math

pi = -3.14
 
x = 5
y = 10
z = 20 

#print(round(pi))
#print(math.ceil(pi))
#print(math.floor(pi))
#print(abs(pi))
#print(pow(pi,2))
#print(math.sqrt(520))
#print(max(x,y,z))
#print(min(x,y,z))  