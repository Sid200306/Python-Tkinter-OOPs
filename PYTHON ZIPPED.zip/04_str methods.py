name = "Siddhesh"
#print(len(name)) 
#print(name.find("d"))
#print(name.capitalize())
#print(name.upper())
#print(name.lower())
#print(name.isdigit())
#print(name.isaplha())
#print(name.count("d"))
#print(name.replace("d","a"))
#print(name*4)

