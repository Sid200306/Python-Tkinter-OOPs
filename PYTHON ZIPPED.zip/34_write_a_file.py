text = "Yooooooooo!!!!!!!!!\nthis is some text\nHave a good day\n"

with open('abc.txt','w') as file:
    file.write(text)