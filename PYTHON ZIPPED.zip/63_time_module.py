import time

#print(time.ctime(0))       # converta time in seconds since epoch to a readable string
                            # epoch = when your computer thinks time began (reference point)

#print(time.time())    # returns seconds since epoch

#print(time.ctime(time.time())) 

#time_object = time.localtime()
#print(time_object)

#local_time = time.strftime("%B %d %Y %H:%M:%S",time_object)
#print(local_time)

#time_object = time.gmtime()
#print(time_object)

#time_string = "6 January, 2003"
#time_object = time.strptime(time_string,"%d %B, %Y")
#print(time_object)


# (year,month,day,hr,mins,secs,day of the week,day of the year,dst)
time_tuple = (2003,1,6,8,20,0,0,6,0)
time_object = time.asctime(time_tuple)
print(time_object)
