from tkinter import *
import time

WIDTH = 500
HEIGHT = 500


window = Tk()

canvas = Canvas(window,width=WIDTH,height=HEIGHT)
canvas.pack()

window.mainloop()