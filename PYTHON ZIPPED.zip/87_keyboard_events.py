from tkinter import Tk, Label

def doIt(event):
    label.config(text=event.keysym)

windows = Tk()

windows.bind("<Key>", doIt)

label = Label(windows, font=("Helvetica", 20))  # Adjusted font size

label.pack()  # Added pack to make the label visible

windows.mainloop()
