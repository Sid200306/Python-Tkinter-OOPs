from tkinter import *

def DoIt(event):
    print("Mouse Co-ordinates: " + str(event.x)+" "+str(event.y))

window = Tk()

#window.bind("<Button-1>",DoIt) #left mouse click
#window.bind("<Button-2>",DoIt)  # scroll wheel
#window.bind("<Button-3>",DoIt)   # right click
#window.bind("<ButtonRelease>",DoIt)
#window.bind("<Enter>",DoIt) #enter the window
#window.bind("<Leave>",DoIt)   # leave the window
window.bind("<Motion>",DoIt) # where the mouse moves

window.mainloop()