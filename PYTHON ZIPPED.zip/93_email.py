import smtplib

sender = "202001022.siddheshndd@student.xavier.ac.in"
receiver = "siddheshlovesmusic@gmail.com"
password = "Siddhesh@2003"
subject = "Python Email Test"
body = "I wrote an email ;)"

#header
message= f"""From: Sidd{sender}
To: Rohit{receiver}
Subject: {subject}\n
{body}
"""

server = smtplib.SMTP("smtp.gmail.com",587)
server.starttls()

try:
  server.login(sender,password)
  print("Logged In......")
  server.sendmail(sender,receiver,message)
  print("Email has been sent!")

except smtplib.SMTPAuthenticationError:
  print("Failed to log in...")
      