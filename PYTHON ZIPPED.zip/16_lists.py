# list = used to store multiple items in a single variable

food = ["pizza","burger","sandwich","rolls","drinks"]
food[0] = "sushi" 
#print(food)

#food.append("ice-cream")
#food.remove("sandwich")
#food.pop()
#food.insert(3,"cake")
#food.sort()
#food.clear()
for x in food:
    print(x)
