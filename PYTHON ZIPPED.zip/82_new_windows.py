from tkinter import *

def create_window():
    new_window = Toplevel() # creates new_window on 'on top of' other windows, linked to a bottom window
                            # Tk() creates a new independent window
window = Tk()

Button(window,text="create new window",command=create_window).pack()

window.mainloop()