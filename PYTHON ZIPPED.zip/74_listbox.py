# listbox = A list of selectable text items within its own container

def submit():
    food=[]
    for i in listbox.curselection():
        food.append(listbox.get(i))

    print("You have ordered:")
    for item in food:
        print(item)

def add():
    listbox.insert(listbox.size(), entryBox.get())

def delete():
    listbox.delete(listbox.curselection())
    listbox.config(height=listbox.size())

from tkinter import *

window = Tk()

listbox = Listbox(window,
                  bg="#faf9cd",
                  font=("Georgia",20),
                  width=12,
                  selectmode=MULTIPLE
                  )
listbox.pack()

listbox.insert(0,"pizza")
listbox.insert(1,"burger")
listbox.insert(2,"fries")
listbox.insert(3,"ice-cream")

listbox.config(height=listbox.size())

entryBox = Entry(window)
entryBox.pack()


submitButton = Button(window,text="submit",command=submit)
submitButton.pack()

addButton = Button(window, text="add", command=add)
addButton.pack()

deleteButton = Button(window, text="delete", command=delete)
deleteButton.pack()

window.mainloop()