# sort() method = used with lists
# sort () function + used with iterables

#students =("Siddhesh","Vishal","Chinmaay","Anurag","Rohit","Anirudha")

#students.sort(reverse=True)

#sorted_students = sorted(students,reverse=True)

#for i in sorted_students:
  #  print(i)


students =[("Siddhesh","A","20"),
("Vishal","B","21"),
("Chinmaay","C","22"),
("Anurag","D","23"),
("Rohit","E","19"),
("Anirudha","F","24")]

grade =lambda grades:grades[1]
age=lambda ages:ages[2]

students.sort(key=age)    # can also add reverse=True into argument to reverse the sorting

for i in students:
    print(i)