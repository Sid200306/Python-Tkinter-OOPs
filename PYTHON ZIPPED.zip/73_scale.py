from tkinter import *

def submit():
    print("The temperature is "+(str(scale.get())+" degrees C"))

window = Tk()

scale = Scale(window,
              from_=100,
              to=0,
              font=('Georgia,20'), #sets font of scale
              length=600, # sets length of scale
              orient=VERTICAL, # orientation of scale
              fg='green', # sets fg color
              bg='black',# sets bg color
              tickinterval=10, # adds numeric indicator
              showvalue=0,
              troughcolor= 'yellow'
              )
scale.pack()


button= Button(window,text='submit',command=submit)
button.pack()

window.mainloop()