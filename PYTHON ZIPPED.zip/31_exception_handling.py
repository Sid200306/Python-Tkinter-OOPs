# exception =  events detected during exceution of program that interrupt the flow of program.

try:
    numerator = int(input("Enter a number to divide: "))
    denominator = int(input("Enter a number to divide by: "))
    result = numerator / denominator
    

except ZeroDivisionError:
    print("You can't divide a number by zero, idiot!!!")
except ValueError:
    print("Enter only number pls!")
except Exception:
    print("Something went wrong :(")
else:
    print(result)