#def hello():
 #   print("Hello")
#
#hi = hello
#hi()

say = print
say("Whoa I cant belive this works :O !!!!!!!!")