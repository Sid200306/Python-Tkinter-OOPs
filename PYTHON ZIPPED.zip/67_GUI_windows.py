from tkinter import *

# widgets = GUI elements : buttons,textboxes, labels,images
# windows = serves as a container to hold on or contain these widgets

window = Tk()  # instantiate an instance of a window
window.geometry("420x420") 
window.title("Sidd N")

#icon = PhotoImage(file = 'FORM PHOTO 2.jpg')
#window.iconphoto(True,icon)
window.config(background="#f2f765")

window.mainloop() # place window on computer screen, listen for events
