# scope = the region that a variable is recognised
#         A variable is only available from the region it is created
#         A global and locally scoped versions of a variable can be created

name = "Sidd"          # global scope(available inside and outside the function)

def display_name():
    name = "Navghare"          # local scope (available only inside this function)
    print(name)

display_name()                    # L = Local
print(name)                       # E = Enclosing
                                  # G = Global
                                  # B = Built - in


