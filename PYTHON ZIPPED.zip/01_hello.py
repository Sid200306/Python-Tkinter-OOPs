print("Hello World!")
print("I love pizza")