import random 

x = random.randint(1,6)
y = random.random()

myList = ['rock','paper','scissors']
z = random.choice(myList)
print(x)
print(z)
print(y)


cards = [1,2,3,4,5,6,7,8,9,10,"J","Q","A","K"]

random.shuffle(cards)
print(cards)

