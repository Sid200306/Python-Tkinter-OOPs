from tkinter import *

# label = an area widget that holds text and/or image within a window

window = Tk()  # instantiate an instance of a window
window.geometry("420x420") 
window.title("Sidd N")
window.config(background="#f2f765")


photo = PhotoImage(file='FORM PHOTO 2.jpg')

label = Label(window,text="Hello Sidd",
              font=('Arial','40','bold'),
              fg='#ed8021',
              bg='#0f0102',
              relief= RAISED,
              bd = 10,
              padx = 20,
              pady = 20,
              image=photo,
              compound='bottom')    
label.pack()             

window.mainloop()
