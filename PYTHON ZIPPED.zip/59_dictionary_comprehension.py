# dictionary comprehension = creates dictionary using an expression
#                            can replace for loops and certain lambda functions

# dictionary = {key: expressin for (key,value) in iterable}
# dictionary = {key: expressin for (key,value) in iterable if conditional}
# dictionary = {key: (if/else) for (key,value) in iterable}
# dictionary = {key: fucntion(value) for (key,value) in iterable}

#cites_in_F = {'Mumbai':32,'Delhi':75,'Bengaluru':100,'Pune':50}

#cities_in_C = {key: round(((value-32)*(5/9))) for (key,value) in cites_in_F.items()}

#print(cities_in_C)
# -----------------------------------------------------

#weather ={'Mumbai':'sunny','Delhi':'cloudy','Bengaluru':'overcast','Pune':'windy'}
#print(sunny_weather)

#--------------------------------------

#cities ={'Mumbai':32,'Delhi':75,'Bengaluru':100,'Pune':50}

#temp_cities = {key: ("WARM" if value >= 40 else "COLD") for (key,value) in cities.items()}
#print(temp_cities)

#----------------------------------------

def check_temp(value):
    if value >= 70:
     return "HOT"
    else:
       return "COLD"

cities ={'Mumbai':32,'Delhi':75,'Bengaluru':100,'Pune':50}
temp_cities = {key: check_temp(value) for (key,value) in cities.items()}

print(temp_cities)