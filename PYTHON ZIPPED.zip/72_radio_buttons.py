# radio buttons = similar to checkbox, but you can select only one froma group

from tkinter import *

food = ["pizza","hamburger","hotdog"]

def order():
    if(x.get()==0):
        print("You ordered pizza!")

    elif(x.get()==1):
        print("You ordered hamburger!")

    elif(x.get()==2):
        print("You ordered hotdog!")

    else:
        print("You ordered nothing ;(")

window = Tk()

x = IntVar()

for index in range(len(food)):
    radiobutton = Radiobutton(window,
                              text=food[index],# adds text to radio buttons
                              variable=x, # groups radio buttons together if they sahre teh same variable
                              value=index, # assigns each radio buttons a different value
                              fg='green', # sets fg color
                              bg='black', # sets bg color
                              activeforeground='green', # sets active fg color
                              activebackground='black', # sets active bg color
                              padx=25, # assigns padding to x-axis
                              pady=10,# assigns padding to y-axis
                              font=('Georgia',20), # sets font and size of text
                              indicatoron=0, # eliminates cicular indicators
                              width = 375, # sets width of radio buttons 
                              command = order) # sets command of radio buttons
                            
    
    radiobutton.pack(anchor=W)
window.mainloop()
