# *************************
# if __name__ = '__main__'
# ************************

# why tho?
# 1) Module can be run as a standalone program
# 2) Module can be imported and used by other modules

# Python interpreter sets "special variables" one of which is __name__
#  then python will exceute the code within __main__

import module_two

print(__name__)
print(module_two.__name__)
   