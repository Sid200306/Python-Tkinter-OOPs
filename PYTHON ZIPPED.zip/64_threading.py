# thread = a flow of exceution. like a separate order of instructions.
#          However each thread takes a turn running to achieve its concurrency.
#          (GIL) = Global Interpreter Lock
#          allows only one thread to hold the control of the Python interpreter at any one given time

# cpu bound = program/tasks spend most of its time waiting for internal events(CPU Intensive)
#             use multiprocessing

# io bound = program/tasks spend most of its time waiting for external events (user input,web scraping)
#            use multi - threading

import threading
import time 

def eat_breakfast():
    time.sleep(3)
    print("You eat breakfast!!!!!!!!!")

def drink_juice():
    time.sleep(4)
    print("You drank juice!!!!!!!!!")

def got_dressedup():
    time.sleep(5)
    print("You got dressed up!!!!!!!!!")

x = threading.Thread(target=eat_breakfast,args=())
x.start()

y = threading.Thread(target=drink_juice,args=())
y.start()

z = threading.Thread(target=got_dressedup,args=())
z.start()

x.join()
y.join()
z.join()



#eat_breakfast()
#drink_juice()
#got_dressedup()

print(threading.active_count())
print(threading.enumerate())
print(time.perf_counter())