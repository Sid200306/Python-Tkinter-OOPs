import time

def say_i_love_you(name):
    while True:
        print(f"I love you {name}")
        time.sleep(1)  # Change the time interval (in seconds) as needed

if __name__ == "__main__":
    person_name = "Gauri"
    say_i_love_you(person_name)
