import module_one

print(__name__)
print(module_one.__name__)