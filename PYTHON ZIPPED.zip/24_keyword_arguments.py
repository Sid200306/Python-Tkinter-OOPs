# keywords arguments = keywords preceded by an identifier when we pass them 
#                      to a function, the order of the arguments does'nt matter

# positional arguments
def hello(first,middle,last):
    print("Hello" "+first+" "+middle+" "+last")   

hello(first="Sidd",middle="D",last="Navghare")            