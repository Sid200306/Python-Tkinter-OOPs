#first_name =("Sidd")
#last_name= ("N")
#full_name= first_name +" "+last_name
#print("Hello " + full_name)
#print(type(name))

#age = 20
#age += 1
#print("Your age is:"+str(age))
#print(type(age))

#height = 250.5
#print("Your height is: "+str(height) +"cm")
#print(type(height))

#human = True
#print("Are you a human: "+str(human))
#print(type(human))




