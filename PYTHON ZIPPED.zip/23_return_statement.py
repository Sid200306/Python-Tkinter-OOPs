# return statement = functions send python values/objects back to the caller
#                    These values/objects are known as function's return value

def multiply(number1,number2):
    return number1 * number2

x = multiply(5,4)

print(x)                   