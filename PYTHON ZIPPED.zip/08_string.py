#slicing = create a substring by extracting elemets frm other string
#indexing[] or slice()
# [start:stop:step]

name = "Sidd Navghare"
first_name = name[0:3]
last_name = name[5:]
funky_name = name[0:13:2] 
reversed_string = name[::-1]

print(reversed_string) 


