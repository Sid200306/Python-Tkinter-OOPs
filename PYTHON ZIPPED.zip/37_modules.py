# modules = a file containing python code. May contain functions classes etc.
# used with modular programming to separate program into parts.
from messages import hello,bye

messages.hello()
messages.bye()
