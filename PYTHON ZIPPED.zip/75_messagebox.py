from tkinter import *
from tkinter import messagebox  # imports message box library

def click():
    #messagebox.showinfo(title='This is an info message box',message='You are a person')

    #messagebox.showwarning(title='WARNING',message='You have a VIRUS!')

    #messagebox.showerror(title='ERROR 404!',message='You have an error ;(')

    #if messagebox.askokcancel(title='ask ok cancel',message='Do you want to do a thing?'):
        #print('You did a thing :) ')
    #else:
        #print('You cancelled a thing :( ')

    #if messagebox.askretrycancel(title='ask retry cancel',message='Do you want to retry a thing?'):
        #print('You retried a thing :) ')
    #else:
        #print('You cancelled a thing :( ')

    #if messagebox.askyesno(title='ask yes no',message='Do you like cake?'):
        #print('I like cake too :) ')
    #else:
        #print('Why dont you like cake :( ')

    #print(messagebox.askquestion(title='ask question',message='Do you like pie?'))

    print(messagebox.askyesnocancel(title='Yes No Cancel',message='Do you like to code?'))



window = Tk()

button = Button(window,text = 'click me',command= click)
button.pack()

window.mainloop()