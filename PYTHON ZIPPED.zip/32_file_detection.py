import os

path = "C:\\Users\\navgh\\Desktop\\"

if os.path.exists(path):
    print("This location exists!")
    if os.path.isfile(path):
        print("This is a file!")
    elif os.path.isdir(path):
        print("This is a directory!")
else:
    print("This location does not exists!")