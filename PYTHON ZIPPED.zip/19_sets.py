# set = a collection which is unordered, unindexed with no duplicate values

utensils = {"spoon","fork","knife"}
dishes = {"bowl","plate","cup","knife"}

#utensils.add("napkin")
#utensils.remove("fork")
#utensils.clear() 
#utensils.update(dishes)
#dinner_table = utensils.union(dishes)
#print(dishes.difference(utensils))           
#print(dishes.intersection(utensils))

#for x in dinner_table:
    #print(x)   