# filter()= creates a collection of elements from an iterable for which a function returns true
#
# filter(function,iterable)

friends = [("Siddhesh","20"),
("Vishal","15"),
("Chinmaay","12"),
("Anurag","18"),
("Rohit","19"),
("Anirudha","24")]

age = lambda data:data[1] >= "18"

drinking_buddies = list(filter(age,friends))

for i in drinking_buddies:
    print(i)