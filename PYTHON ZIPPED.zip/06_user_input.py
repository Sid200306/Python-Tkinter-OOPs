name = input("What is yor name? :")
age = int(input("How old are you:"))
height = float(input("How tall are you?:"))

age = age + 1

print("Hello "+name)
print("You are "+str(age)+" years old")
print("Yo are "+str(height)+" cm tall") 
