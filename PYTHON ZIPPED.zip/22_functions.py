# function = a block of code is exceuted only when it is called

def hello(first_name,last_name,age):
    print("hello!"  +first_name  + last_name)
    print("You are "+str(age)+" years old!")
    print("Have a nice day!!")

#name = "Dude"
#hello("Sidd")
#hello("Bro")
hello("Sidd","Navghare",20)
