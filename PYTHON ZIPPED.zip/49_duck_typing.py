# Duck typing = conccept when the class of the object is less important than the minimum methods/atrributes
#               class type is not checked of minimum methods/atrributes are present
#               "If it walks like a duck, quacks like a duck then it must be a duck."

class Duck:

    def walk(self):
        print("This duck is walking")

    def talk(self):
        print("This duck is quacking")

class Chicken:

    def walk(self):
        print("This chicken is walking")

    def talk(self):
        print("This chicken is chuckling")

class Person:

    def catch(self,duck):
        duck.walk()
        duck.talk()
        print("You caught the critter!!")

duck = Duck()
chicken = Chicken()
person = Person()

person.catch(duck)
person.catch(duck)


