# dictionary = A changebale, unordered collection of unique key: value pairs
#              fast becauswe they use hashing, allow us to access a value quickly

capitals = {'India':'New Delhi',
            'USA':'Washington DC',
            'Russia':'Moscow',
            'Sri Lanka':'Colombo'}

capitals.update({'Germany':'Berlin'})
capitals.update({'USA':'Las Vegas'})
capitals.pop('Sri Lanka')
capitals.clear()

#print(capitals['India'])
#print(capitals.get('UK'))         
#print(capitals.keys())
#print(capitals.values())
#print(capitals.items())

for key,values in capitals.items():
    print(key,values)