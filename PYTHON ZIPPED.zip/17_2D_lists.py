# 2D lists = a list of the lists

drinks = ["coffee","soda","tea"]
dinner = ["butter chicken","biryani","paneer tikka"]
dessert = ["cake","ice-cream","falooda"] 
           
food = [drinks,dinner,dessert]

print(food[2][2])   